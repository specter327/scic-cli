#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

python3 -m pip install --upgrade build twine
rm -rf build dist ./*.egg-info src/*.egg-info
python3 -m build
python3 -m twine check dist/*

if [[ "${1:-}" == "--test" ]]; then
    python3 -m twine upload --repository testpypi dist/*
else
    python3 -m twine upload dist/*
fi
